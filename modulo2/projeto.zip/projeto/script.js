var element = document.querySelector('body');

element.addEventListener('click', function () {
  element.innerHTML = "<div class='mensagem-classe'><h2 id=mensagem-id>Espero que tenham gostado!</h2></div>";
});